'use strict';
const fs=require('node:fs'),path=require('node:path');
const previous=JSON.parse(fs.readFileSync(path.join(__dirname,'versions/0.3.0.json')));
const bookQuests=require('./book-pickups.json').books;
const installed=['0.4.0','0.4.1','0.4.2','0.4.3','0.4.4','0.4.5','0.4.6','0.4.7','0.4.8','0.4.9','0.4.10','0.4.11','0.4.12','0.4.13','0.4.14','0.4.15','0.4.16','0.4.17','0.4.18','0.4.19','0.4.21','0.4.22','0.4.24','0.4.25','0.4.26','0.4.27','0.4.28','0.4.29','0.4.30','0.4.31','0.4.32','0.4.32-goulash.1','0.4.32-goulash.2','0.4.32-goulash.3','0.4.32-goulash.4','0.4.32-goulash.5','0.4.33','0.4.34','0.4.35','0.4.36'].map(version=>({version,...JSON.parse(fs.readFileSync(path.join(__dirname,`versions/${version}.json`)))}));
function key(g){
  // Optionality wording changed without changing the saved layout fingerprint.
  if(g.t==='note'&&["Place the Extra-Destructive Explosives at the forge when your quest directs it. The event has no numbered counter in the reference data; confirm its completion before leaving.","Only if you accepted the optional explosives quest: place the Extra-Destructive Explosives at the forge when it directs you. The event has no numbered counter in the reference data; confirm its completion before leaving."].includes(g.text))
    return JSON.stringify(['note','optional-forge-explosives-reminder']);
  // The specific Messenger drop replaces the same whole-quest objective.
  if(g.quest===142&&(g.t==='complete'||g.t==='collect'&&g.item===1381&&g.oi===1))
    return JSON.stringify(['defias-messenger-message',142,1381]);
  // The verified cave mouth replaces the old Fel Rock approach marker. Only
  // this exact travel pair shares progress; nearby travel and Melenas do not.
  if(g.map===1438&&!g.quest&&!g.npc&&!g.item&&!g.object&&
    (g.t==='goto'&&g.text==='Fel Rock'&&g.x===54&&g.y===52||
     g.t==='explore'&&g.text==='Fel Rock entrance'&&g.x===54.60&&g.y===52.10))
    return JSON.stringify(['travel','Fel Rock entrance',1438]);
  // #356's private targeting workarounds still represent the same item objectives.
  const kind=g.t==='kill'&&(
    g.quest===4161&&g.oi===1&&g.item===5465&&g.npc===1998||
    g.quest===38&&g.oi===1&&g.item===729&&g.npc===199
  )?'collect':g.t;
  if(g.t==='note')return JSON.stringify(['note',g.text]);
  if(g.t==='kill'&&(g.target?.startsWith('Return alive to ')||g.target==='Die and release'))return JSON.stringify(['spiritreturn',g.map,g.x,g.y]);
  // The starter's selling/water errands now use the observed drink vendor.
  // Preserve their old completion when the redundant Lyrai stop is merged.
  // Choosing the central Lakeshire repairer keeps the same vendor visit.
  // Existing nearest-vendor completion must not reopen as a second stop.
  const npc=g.t==='vendor'&&g.npc===956?null:g.t==='buy'&&g.item===159&&g.count===1&&[3608,6736].includes(g.npc)?6736:
    g.npc===3587&&(g.t==='vendor'||g.t==='buy'&&g.item===159)?6091:g.npc;
  // Adding the recorded NPC target does not change a named bind or flight unlock.
  if(['sethome','getfp'].includes(g.t)&&g.location)return JSON.stringify([g.t,g.location]);
  return JSON.stringify([kind,g.quest||null,g.oi||null,g.item||null,g.spell||null,(kind==='collect'||g.quest&&['accept','turnin'].includes(kind))?null:npc||null,
    g.object||null,g.level||null,g.location||null,g.profession||g.skillLine||null,
    ['goto','explore'].includes(g.t)?[g.map,g.x,g.y]:null,
    !g.quest&&!g.npc&&!g.item&&!g.spell&&!g.location&&!g.level ? g.target||g.text||null:null]);
}
function plan(old,current){
  const goalMap={},stepMap={},pinMap={},pinReset={},arrivalRecovery=[],unmatched=[],bookMoves=[],travelBypass=[];
  for(const [s,step]of old.steps.entries()){
    const oldKeys=step.goals.map(key);
    const title=step.title==='Lyrai: sell junk and buy water'?'Dellylah: sell junk and buy water':step.title;
    const ranked=current.filter(g=>g.id===old.id||(old.id==='aurum-druid/westfall-early'&&g.id==='aurum-druid/westfall-return')).flatMap(g=>g.steps.map((n,i)=>({guide:g.id,step:i+1,value:n,
      score:n.goals.reduce((sum,v)=>sum+(oldKeys.includes(key(v))?1:0),0)+(n.title===title?0.25:0)}))).sort((a,b)=>b.score-a.score);
    let owner=ranked[0]&&ranked[0].score>0&&(!ranked[1]||ranked[0].score>ranked[1].score)?ranked[0]:null;
    if(old.id==='aurum-druid/westfall-early'&&step.title==='Prepare for the Hall of Thanes'&&step.goals.some(g=>g.t==='sethome'&&g.location==='Goldshire')){
      // Only the bind moves to the first inn visit. Keep the late vendor
      // completion and view pin at the final visit, not at its similar twin.
      owner=ranked.find(p=>p.guide===old.id&&p.value.title===step.title);
      if(!owner)throw Error('Goldshire hearth move needs its final inn visit');
    }
    if(owner){
      if(owner.guide===old.id)pinMap[s+1]=owner.step;
      if(JSON.stringify(oldKeys)===JSON.stringify(owner.value.goals.map(key)))stepMap[s+1]=owner.guide===old.id?owner.step:{guide:owner.guide,key:owner.step};
    }
    for(const [i,goal]of step.goals.entries()){
      const k=key(goal),at=`${s+1}:${i+1}`;
      const candidates=current.filter(g=>g.id===old.id||(old.id==='aurum-druid/redridge-outdoors'&&g.id==='aurum-druid/redridge-early'&&[118,119,124].includes(goal.quest))||(old.id==='aurum-druid/hall-of-thanes'&&g.id==='aurum-druid/westfall-return'&&goal.t==='getfp'&&goal.location==='Sentinel Hill')||(old.id==='aurum-druid/westfall-return'&&g.id==='aurum-druid/deadmines'&&[167,168,2040].includes(goal.quest))||(old.id==='aurum-druid/westfall-early'&&
        ((g.id==='aurum-druid/westfall-return')||
         (g.id==='aurum-druid/westfall-deadmines'&&goal.quest===64))))
        .flatMap(g=>g.steps.flatMap((st,j)=>st.goals.flatMap((v,n)=>key(v)===k?[{guide:g.id,step:j+1,key:`${j+1}:${n+1}`}]:[])));
      const owned=owner&&candidates.filter(p=>p.guide===owner.guide&&p.step===owner.step);
      let selected=candidates.length===1?candidates[0]:owned&&owned.length===1?owned[0]:null;
      if(old.id==='aurum-druid/start-here'&&goal.t==='fly'){
        const outbound=goal.location==='Auberdine'&&step.goals.some(g=>g.t==='complete'&&g.quest===6001);
        const inbound=goal.location==="Rut'theran Village"&&step.goals.some(g=>g.t==='turnin'&&g.quest===6001);
        if(outbound||inbound){
          // Match the particular Bear Form crossing, not another flight to
          // the same town earlier or later in this chapter.
          const anchor=outbound?'accept':'complete';
          const targets=candidates.filter(p=>current.find(g=>g.id===p.guide).steps[p.step-1].goals.some(v=>v.t===anchor&&v.quest===6001));
          if(targets.length!==1)throw Error('Bear Form flight move needs one reviewed destination');
          selected=targets[0];
          arrivalRecovery.push({goal:at,quest:6001,maps:outbound?[1439]:[1438,1457],...(inbound?{ready:true}:{}),resume:selected.step+1});
        }
      }
      // Retire the old window-only class-training tick at Mardant. It must
      // never check the new learned spells, or another later trainer visit.
      if(old.id==='aurum-druid/start-here'&&goal.t==='train'&&step.goals.some(g=>g.t==='turnin'&&[3120,457].includes(g.quest)))selected=null;
      if(!selected&&goal.t==='accept'&&goal.quest===92745){
        selected=candidates.find(p=>current.find(g=>g.id===p.guide).steps[p.step-1].goals.some(v=>v.t==='turnin'&&v.quest===92742));
      }
      if(old.id==='aurum-druid/start-here'&&at==='34:9'&&goal.t==='train'){
        const targets=candidates.filter(p=>current.find(g=>g.id===p.guide).steps[p.step-1].title==='Level 10 and Bear Form training');
        if(targets.length!==1)throw Error('Reviewed level-10 trainer move no longer matches');
        selected=targets[0];
      }
      if(selected){
        goalMap[at]={guide:selected.guide,key:selected.key};
        if(goal.t==='collect'&&goal.optional&&bookQuests.some(b=>b.item===goal.item)){
          const destination=current.find(g=>g.id===selected.guide).steps[selected.step-1];
          if(destination.goals.length!==1||destination.goals[0].optional)throw Error('Book pickup migration needs a separate required step');
          bookMoves.push({from:at,guide:selected.guide,step:selected.step});
        }
      }else unmatched.push({key:at,type:goal.t,quest:goal.quest});
    }
  }
  if(old.id==='aurum-druid/start-here'){
    for(const recovery of arrivalRecovery){
      const from=Number(recovery.goal.split(':')[0]);
      pinMap[from]=recovery.resume-1;pinReset[from]=true;
    }
    const dock=current.find(g=>g.id===old.id).steps.findIndex(s=>s.goals.some(g=>g.t==='turnin'&&g.quest===6344))+1;
    for(const [i,step]of old.steps.entries())if(
      step.goals.some(g=>g.t==='turnin'&&g.quest===6344)&&step.goals.some(g=>g.t==='turnin'&&g.quest===6341)||
      step.title==='Supplies for Stormwind Harbor'&&step.goals.some(g=>g.t==='buy'&&g.item===6529)){
      // The old Nessa/Vesprystus visit split. Resume at Nessa's unfinished
      // shopping; retain quest ticks at their own NPC, never skip the flight.
      pinMap[i+1]=dock;pinReset[i+1]=true;
    }
    const camp=current.find(g=>g.id===old.id).steps.findIndex(s=>s.goals.some(g=>g.t==='complete'&&g.quest===96606))+1;
    for(const [i,step]of old.steps.entries())if(step.goals.some(g=>g.t==='complete'&&g.quest===96606)&&!step.goals.some(g=>g.t==='accept'&&g.quest===96606)){
      // This visit split across the camp/building and Zarrin stops. Resume at
      // its first unfinished work; mapped checks retain completed errands.
      pinMap[i+1]=camp;pinReset[i+1]=true;
    }
    const first=current.find(g=>g.id===old.id).steps.findIndex(s=>s.title==='The Balance of Nature')+1;
    for(const [i,step]of old.steps.entries())if(step.goals.some(g=>g.t==='kill'&&g.quest===456)&&step.goals.some(g=>g.t==='collect'&&g.quest===459)){
      // A split step resumes at its first stop, never at the most numerous
      // later goals. Existing goal completion still advances normal progress.
      pinMap[i+1]=first;pinReset[i+1]=true;
    }
    const trainer=current.find(g=>g.id===old.id).steps.findIndex(s=>s.title==='Mardant: train your Druid spells')+1;
    for(const [i,step]of old.steps.entries())if(step.goals.some(g=>g.t==='turnin'&&[3120,457].includes(g.quest))&&step.goals.some(g=>g.t==='train')){
      pinMap[i+1]=trainer;pinReset[i+1]=true;
    }
  }
  if(old.id==='aurum-druid/redridge-outdoors'){
    // Deliveries and gnoll kills moved into the earlier combined bridge pass.
    // A character pinned on the retired delivery resumes at local errands;
    // completed goals themselves migrate across chapters by quest identity.
    for(const [i,step] of old.steps.entries())if(step.title==='Goldshire on the Redridge return')pinMap[i+1]=1;
  }
  if(old.id==='aurum-druid/westfall-early'){
    const own=current.find(g=>g.id===old.id),ready=own.steps.findIndex(s=>s.title==='Prepare for the Hall of Thanes')+1;
    const firstWestfall=old.steps.findIndex(s=>s.title==='Jansen Stead on the way into Westfall');
    for(const[i,step]of old.steps.entries())if((firstWestfall>=0&&i>=firstWestfall)||/Level 13 before Westfall|Prepare for Hall of Thanes/.test(step.title)){
      pinMap[i+1]=ready;pinReset[i+1]=true;
    }
  }
  if(old.id==='aurum-druid/hall-of-thanes'){
    const beforeMap=current.find(g=>g.id===old.id).steps.findIndex(s=>s.title==="Steelgrill's Depot: a visitor to Dun Morogh")+1;
    for(const [i,step]of old.steps.entries())if(step.title==='The map prerequisite'){
      pinMap[i+1]=beforeMap;pinReset[i+1]=true;
    }
  }
  if(old.id==='aurum-druid/westfall-return'&&old.steps[0].goals.some(g=>g.t==='hearth'&&g.location==='Goldshire')){
    const own=current.find(g=>g.id===old.id);
    if(own.steps[0].title!=='Stormwind training after the Hall'||own.steps[0].goals[0].t!=='train')throw Error('Post-Hall training replacement needs review');
    // The retired hearth check cannot complete the new training visit.
    pinMap[1]=1;pinReset[1]=true;
  }
  if(old.id==='aurum-druid/westfall-return'){
    const own=current.find(g=>g.id===old.id);
    const arrival=own.steps.findIndex(s=>s.title==='Stormwind: return after Westfall')+1;
    if(!arrival)throw Error('Westfall fallback requires its separate flight visit');
    for(const [i,step]of old.steps.entries())if(step.title==='Stormwind training after Westfall'&&step.goals.some(g=>g.t==='fly')){
      // The flight still comes first; only underlevelled runs take the inserted
      // city errands. Keep existing checks on flight, training and shopping.
      pinMap[i+1]=arrival;pinReset[i+1]=true;
    }
  }
  if(old.id==='aurum-druid/ruins-of-lordaeron'){
    const own=current.find(g=>g.id===old.id);
    const arrival=own.steps.findIndex(s=>s.title==='Southshore arrival')+1;
    if(!arrival)throw Error('Through-boat route needs its Southshore arrival');
    for(const [i,step]of old.steps.entries())if(
      step.title==='Menethil: learn the flight path'||step.title==='Menethil: board for Southshore'){
      // These retired stops never certify arrival at Southshore. Keep their
      // old ticks in the revision backup and resume at the real destination.
      pinMap[i+1]=arrival;pinReset[i+1]=true;
    }
  }
  if(old.id==='aurum-druid/ruins-of-lordaeron'){
    const own=current.find(g=>g.id===old.id);
    const entry=own.steps.findIndex(s=>s.title==='Through Alterac to the lake east of Dalaran')+1;
    const shore=own.steps.findIndex(s=>s.title==='Swim to the shore east of Undercity')+1;
    const gate=own.steps.findIndex(s=>s.title==='Enter with your group')+1;
    for(const [i,step]of old.steps.entries()){
      const destination=step.title==='Reach Lordamere Lake beside Dalaran'?entry:
        step.title==='Swim north along Lordamere Lake'?shore:step.title==='Approach the outer city gate'?gate:0;
      if(destination){
        pinMap[i+1]=destination;pinReset[i+1]=true;
        // Bypass replaced travel after an old completed visit; never grant
        // arrival at the new point or complete any dungeon objective.
        if(destination!==gate)travelBypass.push({from:`${i+1}:1`,to:`${destination}:1`});
      }
    }
  }
  let addedBindRecovery;
  if(old.id==='aurum-druid/hall-of-thanes'&&!old.steps.some(s=>s.goals.some(g=>g.t==='sethome'&&g.location==='Stormwind City'))){
    const own=current.find(g=>g.id===old.id);
    if(own.steps[0].goals.filter(g=>g.t!=='note').length!==1||own.steps[0].goals[0].t!=='sethome')throw Error('Pre-Hall bind recovery needs its own visit');
    addedBindRecovery={step:1};
  }
  let xpBufferRecovery;
  if(old.id==='aurum-druid/hall-of-thanes'&&!old.steps.some(s=>s.goals.some(g=>[432,433].includes(g.quest)))){
    const own=current.find(g=>g.id===old.id);
    const fromStep=old.steps.findIndex(s=>s.title==='Ironforge pickups')+1;
    const goals=own.steps.flatMap((s,si)=>s.goals.flatMap((g,gi)=>[432,433].includes(g.quest)?[`${si+1}:${gi+1}`]:[]));
    const steps=own.steps.flatMap((s,si)=>s.goals.length&&s.goals.every(g=>[432,433].includes(g.quest))?[si+1]:[]);
    if(!fromStep||goals.length!==6||steps.length!==3)throw Error('Hall XP buffer recovery needs its reviewed visits');
    // Existing level-13 characters already past outdoor preparation need no
    // retroactive XP detour. Preserve this as skipped work, never completion.
    xpBufferRecovery={level:13,fromStep,afterQuests:[96390,96391],goals,steps};
  }
  return {goalMap,stepMap,pinMap,pinReset,arrivalRecovery,unmatched,...(travelBypass.length?{travelBypass}:{}),...(bookMoves.length?{bookMoves}:{}),...(xpBufferRecovery?{xpBufferRecovery}:{}),...(addedBindRecovery?{addedBindRecovery}:{})};
}
function compose(old,via,guide){
  const goalMap={},stepMap={},pinMap={};
  for(const[k,v]of Object.entries(old.goalMap||{})){const result=via.goalMap[v];if(result)goalMap[k]=result;}
  for(const[k,v]of Object.entries(old.stepMap||{}))if(via.stepMap[v])stepMap[k]=via.stepMap[v];
  for(const[k,v]of Object.entries(old.pinMap||{}))if(via.pinMap[v])pinMap[k]=via.pinMap[v];
  return {old:old.old,goalMap,stepMap,pinMap,unmatched:old.unmatched||[],from:guide};
}
function migration(guides,identity,version){
  const result={version:2,revision:version,guides:{}};
  for(const g of guides){
    const p=previous.guides.find(o=>o.id===g.id), prior=previous.migration.guides[g.id];
    const rules=[];
    if(p){
      const movement=plan(p,guides);
      rules.push({old:identity(p),...movement,from:'0.3.0'});
      if(prior.old.shape!==identity(p).shape||JSON.stringify(prior.old.keys)!==JSON.stringify(identity(p).keys))rules.push({old:prior.old,...movement,from:'aurum22'});
      for(const historical of prior.historical||[])rules.push(compose(historical,movement,'historical starter'));
    }
    for(const version of installed){
      const recent=version.guides.find(o=>o.id===g.id);
      if(recent&&!rules.some(r=>r.old.shape===identity(recent).shape&&JSON.stringify(r.old.keys)===JSON.stringify(identity(recent).keys)))rules.push({old:identity(recent),...plan(recent,guides),from:version.version});
    }
    const safety={
      'aurum-druid/westfall-deadmines':{level:16,title:'Back to Westfall'},
    }[g.id];
    let levelGuard;
    if(safety){
      const step=g.steps.findIndex(s=>s.title===safety.title)+1;
      const resume=safety.resume?g.steps.findIndex(s=>s.title===safety.resume)+1:step;
      if(!step||!resume)throw Error('Reviewed safety checkpoint missing: '+g.id);
      levelGuard={level:safety.level,step,resume};
    }
    result.guides[g.id]={new:identity(g),old:prior?.old||identity(g),historical:rules,...(levelGuard?{levelGuard}:{})};
  }
  return result;
}
module.exports={migration,plan,key};
