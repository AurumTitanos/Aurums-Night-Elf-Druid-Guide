'use strict';
// Private authoring stays pinned separately from the independently updated game addon.
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../..');
const authoring = process.env.AURUM_AUTHORING_REPO || path.join(root, 'polestar');
const { commandPack } = require(path.join(authoring, 'tools/lib/pack/locate'));
const { buildPack } = require(path.join(authoring, 'tools/lib/pack/build'));
const { buildPackFiles, writePackDir } = require(path.join(authoring, 'tools/lib/dsl/project'));
const { luaValue } = require(path.join(authoring, 'tools/lib/playtest'));
const packDir = path.join(root, 'druid-guide');
const baselineFile = path.join(__dirname, 'baseline-identities.json');
function hash(text) { let h=5381; for (const b of Buffer.from(text)) h=(h*33+b)>>>0; return h; }
function identity(guide, legacy=false) {
  const parts=guide.steps.map(step=>step.goals.map(g=>{
    const named=legacy&&(g.t==='getfp'||g.t==='sethome'&&g.resolvedInn);
    return `${g.t}:${named&&g.location||g.quest||g.npc||g.item||g.spell||g.object||g.faction||g.achievement||g.level||g.location||g.map||''}`;
  }).join(','));
  return {shape:`${parts.length}-${hash(parts.join('|'))}`,keys:parts.map(hash)};
}
function semanticGoal(g) {
  if(g.t==='getfp'||g.t==='sethome')return `${g.t}:${g.location||g.npc}`;
  if(g.t==='note')return `note:${g.text}`;
  return JSON.stringify([g.t,g.quest||null,g.oi||null,g.item||null,g.spell||null,g.object||null,g.level||null,g.location||null,(!g.quest&&!g.item&&!g.spell&&!g.object?g.npc:null)||null,g.t==='spiritreturn'?[g.map,g.x,g.y]:null]);
}
function historicalRule(current) {
  const history=JSON.parse(fs.readFileSync(path.join(__dirname,'historical-starter.json'),'utf8'));
  const old=history.guide, goalMap={}, stepMap={}, pinMap={}, unmatched=[];
  const oldRefs=new Map(),newRefs=new Map();
  const add=(index,k,p)=>index.set(k,[...(index.get(k)||[]),p]);
  old.steps.forEach((s,i)=>s.goals.forEach((g,j)=>add(oldRefs,semanticGoal(g),`${i+1}:${j+1}`)));
  current.steps.forEach((s,i)=>s.goals.forEach((g,j)=>add(newRefs,semanticGoal(g),`${i+1}:${j+1}`)));
  old.steps.forEach((step,i)=>{
    // Verified insertion: supplies immediately follows the unchanged Rut'theran
    // stop. Remaining chapter visits retain sequence, with two reviewed renames.
    const ns=i<39?i:i+1, target=current.steps[ns];
    const renamed={40:['Boat to Auberdine','Flight to Auberdine'],45:['Auberdine','Boat to Stormwind']}[i+1];
    if(!target||(step.title!==target.title&&!(renamed&&step.title===renamed[0]&&target.title===renamed[1])))throw new Error(`Historical step mapping needs review at ${i+1}`);
    pinMap[i+1]=ns+1;
    const oldGoals=step.goals.map(semanticGoal),newGoals=target.goals.map(semanticGoal);
    if(JSON.stringify(oldGoals)===JSON.stringify(newGoals))stepMap[i+1]=ns+1;
    step.goals.forEach((goal,j)=>{
      const key=semanticGoal(goal),localMatches=newGoals.map((v,k)=>v===key?k:-1).filter(k=>k>=0);
      if(oldGoals.filter(k=>k===key).length===1&&localMatches.length===1)goalMap[`${i+1}:${j+1}`]=`${ns+1}:${localMatches[0]+1}`;
      else if(oldRefs.get(key).length===1&&newRefs.get(key)?.length===1)goalMap[`${i+1}:${j+1}`]=newRefs.get(key)[0];
      else unmatched.push({step:i+1,goal:j+1,identity:key});
    });
  });
  return {old:history.identity,goalMap,stepMap,pinMap,unmatched};
}
function addFlightDepartures(guides,data) {
  const nodes=JSON.parse(fs.readFileSync(path.join(__dirname,'flight-lookups.json'),'utf8'));
  const inns=JSON.parse(fs.readFileSync(path.join(__dirname,'inn-lookups.json'),'utf8'));
  const byId=new Map(guides.map(g=>[g.id,g])),visits=new Set(),report=[];
  const world=p=>{const fr=(p.f==='e'?data.mapFrames.era:data.mapFrames.forever)[p.map]||data.mapFrames.era[p.map];return fr?{c:fr.c,x:fr.left+(fr.right-fr.left)*p.x/100,y:fr.top+(fr.bottom-fr.top)*p.y/100}:null;};
  const landing=name=>nodes.find(n=>n.name===name);
  let current=byId.get('aurum-druid/start-here'),position=null;
  while(current&&!visits.has(current.id)) {
    visits.add(current.id);
    for(const[s,step]of current.steps.entries())for(const[i,g]of step.goals.entries()) {
      if(g.t==='fly') {
        let departure=g.departure;
        if(!departure&&position){const p=world(position);let best=null,distance=Infinity;for(const n of nodes){const q=world({...n,f:'e'});if(!p||!q||p.c!==q.c)continue;const d=(p.x-q.x)**2+(p.y-q.y)**2;if(d<distance){best=n;distance=d;}}if(best)departure={npc:best.npc,npcName:best.npcName,map:best.map,x:best.x,y:best.y,f:'e'};}
        if(!departure)throw new Error(`No verified departure for ${current.id} ${s+1}:${i+1}`);
        Object.assign(g,departure);
        g.note=[g.note,`Speak to ${departure.npcName} and fly to ${g.location}. The arrow leads to the departure flight master; this goal completes at the destination.`].filter(Boolean).join(' ');
        report.push({guide:current.id,step:s+1,goal:i+1,destination:g.location,departure});
        const target=landing(g.location);if(!target)throw new Error(`No verified landing node: ${g.location}`);position={...target,f:'e'};
      } else if(g.t==='hearth') {
        const inn=inns.find(n=>n.name===g.location||n.location===g.location);
        if(!inn||inn.map===undefined)throw new Error(`No verified hearth landing: ${g.location}`);
        position={...inn,f:'e'};
      } else if(!g.optional&&g.map&&g.x!==undefined&&g.y!==undefined)position=g;
    }
    current=byId.get(current.next);
  }
  const detached=guides.filter(g=>!visits.has(g.id));
  for(const g of detached) {
    if(g.id!=='aurum-druid/sleeping-bag')throw new Error('Unexpected detached private guide: '+g.id);
    // This optional excursion has explicit Silva and Auberdine departures.
    for(const[s,step]of g.steps.entries())for(const[i,goal]of step.goals.entries())if(goal.t==='fly'){
      const departure=goal.departure||nodes.find(n=>n.name==="Rut'theran Village");
      if(!departure)throw new Error('Optional guide flight needs a verified departure');
      Object.assign(goal,departure);
      report.push({guide:g.id,step:s+1,goal:i+1,destination:goal.location,departure});
    }
  }
  return report;
}
function convert(guides,data) {
  const out=structuredClone(guides), changes=[];
  const felRock=JSON.parse(fs.readFileSync(path.join(__dirname,'../fel-rock-waypoint.json'),'utf8'));
  for(const guide of out) for(const [s,step] of guide.steps.entries()) for(const [i,g] of step.goals.entries()) {
    if(guide.id===felRock.guide&&g.t==='explore'&&g.text===felRock.label) {
      if(g.map!==felRock.map||g.x!==felRock.x||g.y!==felRock.y)throw Error('Fel Rock entrance moved; re-verify its floor height');
      // The public guide DSL cannot author a height for places. The stock
      // engine supports z in pack goals; use the client-derived cave mouth.
      g.z=felRock.z;
      changes.push({guide:guide.id,step:s+1,goal:i+1,from:'Fel Rock entrance without a floor',to:'verified cave mouth floor',z:g.z});
    } else if(g.t==='collect'&&(
      guide.id==='aurum-druid/start-here'&&g.quest===4161&&g.oi===1&&g.item===5465&&g.npc===1998||
      guide.id==='aurum-druid/westfall-return'&&g.quest===38&&g.oi===1&&g.item===729&&g.npc===199
    )) {
      // Polestar #356: collect target names ignore the explicit NPC. Stock
      // quest-linked kills track the same item objective, but target this NPC.
      // Keep the item count, item, waypoint and spawn areas unchanged.
      g.t='kill'; g.target=g.npcName;
      g.text=`Kill ${g.npcName} for ${g.itemName}`;
      changes.push({guide:guide.id,step:s+1,goal:i+1,from:`collect ${g.itemName}`,to:`quest-tracked ${g.npcName} target; still counts collected items`});
    } else if(g.t==='spiritreturn') {
      // A text-only kill is the stock engine's supported unconditional manual
      // check-off: no npc/quest means kills and gossip cannot auto-complete it.
      // Keep the existing waypoint and manual completion, with concise wording.
      const place=g.text;
      g.t='kill'; g.target='Die and release';
      g.text='Die and release';
      delete g.note;
      changes.push({guide:guide.id,step:s+1,goal:i+1,from:'spiritreturn',to:'manual confirmation',place});
    } else if(g.t==='teleport') {
      const spell=g.spellName;
      g.t='goto'; g.text=`Moonglade — cast ${spell}`;
      g.note=`Cast ${spell} from your spellbook or action bar. This travel goal completes at the destination.`;
      delete g.spell; delete g.spellName;
      changes.push({guide:guide.id,step:s+1,goal:i+1,from:'teleport',to:'goto',spell});
    } else if(g.t==='buy'&&g.quest) {
      // The mandatory turn-in enforces ownership. Optional shopping reminders
      // cannot send an already-finished character back for consumed supplies.
      g.optional=true;
      g.note=[g.note,'Buy only missing supplies for this step. The required quest turn-in checks the actual items; this shopping reminder does not hold the step after the quest is handed in.'].filter(Boolean).join(' ');
      changes.push({guide:guide.id,step:s+1,goal:i+1,from:'quest-linked buy',to:'optional shopping reminder; required turn-in retained'});
    }
  }
  // Keep an optional reward marker for characters who completed the retired
  // harvester task. This deliberately has no accept/kill in the new route.
  // Copy the previously verified resolved hand-in instead of inventing a target.
  const history=JSON.parse(fs.readFileSync(path.join(__dirname,'versions/0.4.0.json')));
  const oldWestfall=history.guides.find(g=>g.id==='aurum-druid/westfall-early');
  const handIn=oldWestfall.steps.flatMap(s=>s.goals).find(g=>g.t==='turnin'&&g.quest===9);
  const westfall=out.find(g=>g.id==='aurum-druid/westfall-return');
  const rewards=westfall.steps.find(s=>s.title==="Saldean's Farm");
  if(!handIn||!rewards)throw Error('Reviewed Killing Fields recovery hand-in is missing');
  rewards.goals.unshift({...structuredClone(handIn),optional:true,
    note:'Recovery reward only: hand this in if already complete. Do not accept it or kill more harvesters for this route.'});
  changes.push({guide:westfall.id,from:'retired quest 9',to:'optional recovery hand-in only; no accept or farming'});
  const flights=data?addFlightDepartures(out,data):[];
  return {guides:out,changes,flights};
}
function compile({review=false}={}) {
  require('../private-reference.cjs').ensure();
  const built=buildPack(commandPack({pack:packDir}),{dataDir:path.join(packDir,'.reference-forever')});
  if(!built.ok) throw new Error(JSON.stringify(built.diag.list,null,2));
  const converted=convert(built.guides,built.data);
  // The client-verified second quest-log line is missing from reference data.
  // 673085 is a verified Tarantula Egg display identity; the counter reads
  // the live quest-log name/index, regardless of which egg variant was clicked.
  for(const guide of converted.guides)if(guide.id==='aurum-druid/redridge-early')
    for(const step of guide.steps)if(step.goals.some(g=>g.t==='kill'&&g.quest===98386&&g.npc===505))
      for(const goal of step.goals)if(goal.t==='complete'&&goal.quest===98386)
        Object.assign(goal,{t:'interact',object:673085,oi:2,count:6,objName:'Tarantula Egg',text:'Destroy Tarantula Eggs'});
  const layouts=Object.fromEntries(converted.guides.map(g=>[g.id,identity(g)]));
  const layoutFile=path.join(__dirname,'versions',built.manifest.version+'-layouts.json');
  if(review)fs.writeFileSync(layoutFile,JSON.stringify(layouts,null,2)+'\n');
  if(!fs.existsSync(layoutFile)||JSON.stringify(layouts)!==JSON.stringify(JSON.parse(fs.readFileSync(layoutFile))))throw new Error('Guide identities changed; review the migration and version layout before building');
  const migration=require('./revision.cjs').migration(converted.guides,identity,built.manifest.version);
  const files=buildPackFiles({...built,guides:converted.guides,license:fs.readFileSync(path.join(packDir,'LICENSE'),'utf8')});
  files['MigrationData.lua']=`local _, pack = ...\npack.migrationData = ${luaValue(migration)}\n`;
  files['ProgressMigration.lua']=fs.readFileSync(path.join(__dirname,'ProgressMigration.lua'),'utf8');
  files['EarlyTraining.lua']=fs.readFileSync(path.join(__dirname,'EarlyTraining.lua'),'utf8');
  files['WestfallLevelFallback.lua']=fs.readFileSync(path.join(__dirname,'WestfallLevelFallback.lua'),'utf8');
  const ruins=converted.guides.find(g=>g.id==='aurum-druid/ruins-of-lordaeron');
  const lake=ruins.steps.flatMap(s=>s.goals).filter(g=>g.t==='goto'&&['Lordamere Lake: eastern entry','Eastern lakeshore: climb toward the Ruins'].includes(g.text));
  if(lake.length!==2)throw Error('The authored lake approach needs its two confirmed checkpoints');
  const lakeNode=g=>{const f=built.data.mapFrames.forever[g.map];if(!f)throw Error('Missing lake map frame');return {map:g.map,c:f.c,wx:f.top+(f.bottom-f.top)*g.y/100,wy:f.left+(f.right-f.left)*g.x/100,r:35};};
  files['LakeApproach.lua']=`local _, pack = ...\nif pack.migrationBlocked then return end\nlocal P = Polestar\nlocal function register()\n if P and P.Nav and P.Nav.RegisterCrossings then P.Nav.RegisterCrossings(${luaValue({crossings:[{id:'aurum-lordamere-swim',a:lakeNode(lake[0]),b:lakeNode(lake[1]),ab:'Swim north through Lordamere Lake in Aquatic Form',ba:'Swim south through Lordamere Lake in Aquatic Form'}]})}) end\nend\nregister()\nif P and P.OnLogin then P.OnLogin(register) end\n`;
  const books=require('./book-pickups.json').books;
  const bookQuests=Object.fromEntries(books.map(b=>[b.item,b.quest]));
  const bookGuides=converted.guides.filter(g=>g.steps.some(s=>s.goals.some(v=>v.t==='collect'&&!v.quest&&bookQuests[v.item]))).map(g=>g.id);
  files['BookPickups.lua']=`local _, pack = ...\npack.bookQuests = ${luaValue(bookQuests)}\npack.bookGuides = ${luaValue(bookGuides)}\n`+fs.readFileSync(path.join(__dirname,'BookPickups.lua'),'utf8');
  const toc=`${built.manifest.folder}.toc`;
  files[toc]=files[toc].replace('Pack.lua\n','MigrationData.lua\nProgressMigration.lua\nPack.lua\n').replace('## X-Polestar-Needs: 0.2.4','## X-Polestar-Needs: 0.2.5');
  files[toc]=files[toc].replace('Guides.lua\n','Guides.lua\nEarlyTraining.lua\nBookPickups.lua\nWestfallLevelFallback.lua\nLakeApproach.lua\n');
  // A mismatched historical save is left untouched and this pack waits rather
  // than allowing stock shape reconciliation to discard unrecognized ticks.
  files['Pack.lua']='local _, pack = ...\nif pack.migrationBlocked then return end\n'+files['Pack.lua'];
  files['Guides.lua']='local _, pack = ...\nif pack.migrationBlocked then return end\n'+files['Guides.lua'];
  files['MapFrames.lua']='local _, pack = ...\nif pack.migrationBlocked then return end\n'+files['MapFrames.lua'];
  return {...built,...converted,files,migration};
}
function build(out=path.join(packDir,'dist','PolestarPack_AurumForeverDruid')) {
  const result=compile();
  writePackDir(out,result.files);
  fs.writeFileSync(path.join(__dirname,'build-report.json'),JSON.stringify({version:result.manifest.version,title:result.manifest.title,folder:result.manifest.folder,authoring,output:out,guides:result.guides.length,steps:result.guides.reduce((n,g)=>n+g.steps.length,0),changes:result.changes,flights:result.flights,warnings:result.diag.list.filter(d=>d.severity==='warning')},null,2)+'\n');
  console.log(`Built private ${result.manifest.title} ${result.manifest.version}: ${result.guides.length} guides at ${out}`);
  return result;
}
module.exports={compile,convert,identity,hash,build,root,authoring};
if(require.main===module)build(process.argv[2]);
