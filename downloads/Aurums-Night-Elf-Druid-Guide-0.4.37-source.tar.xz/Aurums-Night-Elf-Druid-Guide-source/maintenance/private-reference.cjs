'use strict';
// Facts used only by the private pack. No installed official database is edited.
const fs=require('node:fs'),path=require('node:path');
function ensure(){
 const dir=path.resolve(__dirname,'../druid-guide/.reference-forever');
 const source=JSON.parse(fs.readFileSync(path.join(__dirname,'camping-professions.json')));
 const file=path.join(dir,'professions.json');
 const data=fs.existsSync(file)?JSON.parse(fs.readFileSync(file)):{};
 for(const[id,p]of Object.entries(source)){
  const current=data[id]||{name:p.name,recipes:[]};
  const recipes=new Map((current.recipes||[]).map(r=>[r.spell,r]));
  for(const r of p.recipes)recipes.set(r.spell,r);
  data[id]={...current,recipes:[...recipes.values()]};
 }
 const text=JSON.stringify(data,null,2)+'\n';
 if(!fs.existsSync(file)||fs.readFileSync(file,'utf8')!==text)fs.writeFileSync(file,text);
 const qfile=path.join(dir,'quests.json'),q=JSON.parse(fs.readFileSync(qfile));let changed=false;
 // Released stock route documents these manually observed prerequisites.
 for(const[id,pre]of [[92745,92742],[92747,92745]]){
  if(!q[id])throw Error('Missing private quest reference: '+id);
  if(!(q[id].preAll||[]).includes(pre)){q[id].preAll=[...(q[id].preAll||[]),pre];changed=true;}
 }
 if(changed)fs.writeFileSync(qfile,JSON.stringify(q)+'\n');
 return {recipes:2,questPrerequisites:2,officialFilesChanged:false};
}
module.exports={ensure};
if(require.main===module)console.log(JSON.stringify(ensure()));
