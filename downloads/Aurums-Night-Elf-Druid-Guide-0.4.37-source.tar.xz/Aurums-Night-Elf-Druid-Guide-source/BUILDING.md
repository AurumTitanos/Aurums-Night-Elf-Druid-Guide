# Building Aurums Night Elf Druid Guide 0.4.37

The source archive contains the corresponding source for the guide pack, its build scripts, GPL-licensed authoring tools, the reference data used for this snapshot, and generic historical guide-layout migration inputs. It contains no account/character SavedVariables, personal backups, or custom Planner companion.

Requires Node.js 24 or later. From this extracted directory:

```sh
node maintenance/guide-migration/build.cjs druid-guide/dist/PolestarPack_AurumForeverDruid
```

This recreates the readable addon source in `druid-guide/dist/PolestarPack_AurumForeverDruid`. Zip that folder, retaining its folder name, for installation into `Interface/AddOns/`.

The bundled `polestar/tools` directory is the GPL-licensed authoring toolchain used for this existing route, with local compatibility additions; it is separate from the official game addon. Install official Polestar in game, not this source toolchain. `druid-guide/guides/` contains the editable guide DSL; `maintenance/guide-migration/` contains stock-compatible conversion and migration logic. Historical JSON files describe guide layouts, not player records.

For source linting with this snapshot's reference data:

```sh
cd druid-guide
node ../polestar/tools/polestar.js lint --data .reference-forever --context-data .reference-forever --format json
```

Runtime simulation should be performed against the official Polestar 0.2.6 addon and its fixtures. See the repository VALIDATION.md. Simulations do not constitute in-game testing. Everything past level 20 remains untested and best effort.

GPL-3.0-only. Upstream source and credits are in druid-guide/THIRD-PARTY-CREDITS.txt and polestar/LICENSE. Preserve all original data and code notices.
