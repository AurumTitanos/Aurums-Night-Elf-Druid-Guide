'use strict';

// Capture the native C_Map geometry/art contracts from the client's DB2 export.
// Run with the locally cached build directory. The resulting fixture has no
// machine paths and can exercise the actual OpenMap Lua without a client.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { parseCsv } = require('../../../tools/lib/data/csv');

const source = process.argv[2];
if (!source) throw new Error('Usage: node tests/fixtures/openmap/generate.cjs <DB2 build directory>');
const tables = {};
const hashes = {};
for (const name of ['UiMap', 'UiMapAssignment', 'UiMapArt', 'UiMapArtStyleLayer', 'UiMapArtTile', 'UiMapXMapArt']) {
  const bytes = fs.readFileSync(path.join(source, `${name}.csv`));
  tables[name] = parseCsv(bytes.toString('utf8'));
  hashes[name] = crypto.createHash('sha256').update(bytes).digest('hex');
}
const assignments = new Map();
for (const row of tables.UiMapAssignment) {
  const key = +row.UiMapID;
  if (!assignments.has(key)) assignments.set(key, []);
  assignments.get(key).push(row);
}
const artOf = new Map(tables.UiMapXMapArt.filter(r => +r.PhaseID === 0).map(r => [+r.UiMapID, +r.UiMapArtID]));
const arts = new Map(tables.UiMapArt.map(r => [+r.ID, +r.UiMapArtStyleID]));
const layers = new Map(tables.UiMapArtStyleLayer.filter(r => +r.LayerIndex === 0).map(r => [+r.UiMapArtStyleID, r]));
const maps = {};
for (const map of tables.UiMap) {
  const id = +map.ID;
  const a = assignments.get(id)?.[0];
  const world = assignments.get(947)?.find(r => r.MapID === a?.MapID);
  if (!a || !world || ![1, 2, 3].includes(+map.Type)) continue;
  const U = y => +world.UiMin_0 + (+world.Region_4 - y) / (+world.Region_4 - +world.Region_1) * (+world.UiMax_0 - +world.UiMin_0);
  const V = x => +world.UiMin_1 + (+world.Region_3 - x) / (+world.Region_3 - +world.Region_0) * (+world.UiMax_1 - +world.UiMin_1);
  const l = U(+a.Region_4), r = U(+a.Region_1), t = V(+a.Region_3), b = V(+a.Region_0);
  const width = (r - l) / (+a.UiMax_0 - +a.UiMin_0);
  const height = (b - t) / (+a.UiMax_1 - +a.UiMin_1);
  const rect = id === 947 ? [0, 1, 0, 1] : [l - +a.UiMin_0 * width, l + (1 - +a.UiMin_0) * width, t - +a.UiMin_1 * height, t + (1 - +a.UiMin_1) * height];
  const worldWidth = (+a.Region_4 - +a.Region_1) / (+a.UiMax_0 - +a.UiMin_0);
  const worldHeight = (+a.Region_3 - +a.Region_0) / (+a.UiMax_1 - +a.UiMin_1);
  const left = +a.Region_4 + +a.UiMin_0 * worldWidth;
  const top = +a.Region_3 + +a.UiMin_1 * worldHeight;
  const layer = layers.get(arts.get(artOf.get(id)));
  if (!layer) continue;
  maps[id] = {
    info: { mapID: id, name: map.Name_lang, parentMapID: +map.ParentUiMapID, mapType: +map.Type },
    rect,
    bounds: { c: +a.MapID, left, right: left - worldWidth, top, bottom: top - worldHeight, kx: -1 / worldWidth, ky: -1 / worldHeight },
    artID: artOf.get(id),
    layer: { layerWidth: +layer.LayerWidth, layerHeight: +layer.LayerHeight, tileWidth: +layer.TileWidth, tileHeight: +layer.TileHeight, minScale: +layer.MinScale, maxScale: +layer.MaxScale, additionalZoomSteps: +layer.AdditionalZoomSteps },
    textures: tables.UiMapArtTile.filter(r => +r.UiMapArtID === artOf.get(id) && +r.LayerIndex === 0)
      .sort((a, b) => +a.RowIndex - +b.RowIndex || +a.ColIndex - +b.ColIndex).map(r => +r.FileDataID),
  };
}
const result = { provenance: { build: path.basename(path.resolve(source)), source: 'wago.tools DB2 exports of the WoW Forever client', tables: hashes }, maps };
fs.writeFileSync(path.join(__dirname, 'native-maps.json'), JSON.stringify(result, null, 2) + '\n');
console.log(`Captured ${Object.keys(maps).length} native map definitions`);
