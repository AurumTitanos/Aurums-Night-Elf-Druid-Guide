# OpenMap native map fixtures

`native-maps.json` is generated from WoW Forever build 1.60.1.70425 client-table
exports by `generate.cjs`; its provenance records their hashes.

`MapLand-1414.tga` and `MapZoneLand-1438.tga` are byte-for-byte copies of
OpenMap's `OpenMap/Media/Textures/MapLand/1414.tga` and
`OpenMap/Media/Textures/MapZoneLand/1438.tga`, from
[fitzforge/wowforever-openmap](https://github.com/fitzforge/wowforever-openmap)
commit `849bac460b6ebcb110ef80fc27a6b08565069c74` (OpenMap contributors).
They are small regression fixtures for the real island-mask alpha, rather than
invented shapes. Their hashes are checked against the tracked import provenance.

These masks are derived from Blizzard Entertainment's World of Warcraft map art;
they remain Blizzard's art and are not covered by OpenMap's MIT code license.
See `addon/Polestar/OpenMap/NOTICE.md` and `LICENSE.txt` for attribution and the
original generation sources. The tests create the repaired native-detail mask
from these fixtures without requiring a game install, source checkout, or network.
