// Saved Recorder checkpoints only. Following seeks the route simulation to
// the saved step; simulated position/XP/time are not live character data.
// Each page owns its follow preference.
const FOLLOW_KEY = 'polestar.game-checkpoint.follow';
export const checkpointKey = (status) => status?.lastCheckpoint
	? JSON.stringify([status.lastCheckpoint.character, status.lastCheckpoint.guide, status.lastCheckpoint.step, status.lastCheckpoint.title, status.lastCheckpoint.checkpointAt, status.savedVariablesWrittenAt]) : null;

export function checkpointView(status, now = Date.now()) {
	const checkpoint = status?.lastCheckpoint || null;
	const heartbeat = Date.parse(status?.updatedAt || '');
	const helperStopped = Number.isFinite(heartbeat) ? now - heartbeat > 60000 : ['ready', 'stale'].includes(status?.state);
	const active = ['ready', 'stale'].includes(status?.state) && !helperStopped;
	const at = Date.parse(status?.savedVariablesWrittenAt || checkpoint?.checkpointAt || '');
	const seconds = Number.isFinite(at) ? Math.max(0, Math.floor((now - at) / 1000)) : null;
	const age = seconds === null ? '' : seconds < 60 ? `${seconds}s ago` : seconds < 3600 ? `${Math.floor(seconds / 60)}m ago` : `${Math.floor(seconds / 3600)}h ago`;
	return {
		checkpoint, followAllowed: active && status?.followAllowed === true && !!checkpoint,
		text: checkpoint ? `${checkpoint.character} · Step ${checkpoint.step}: ${checkpoint.title}${age ? ` · saved ${age}` : ''}` : 'Waiting for /psrec on in game, then /reload.',
		detail: helperStopped ? 'Checkpoint helper is not updating. Reopen the Planner launcher.' : status?.message || 'Waiting for /psrec on in game, then /reload.',
		state: helperStopped ? 'stopped' : status?.state || 'waiting',
	};
}

// The controller is independent of DOM so opt-out and repeated polling can
// be tested without a game or browser. A failed/mismatched focus is retried.
export function checkpointFollower({ focus, enabled = true }) {
	let follow = enabled;
	let latest = null;
	let applied = null;
	let busy = false;
	let stopped = false;
	let generation = 0;
	async function apply() {
		if (stopped || busy || !follow || !checkpointView(latest).followAllowed) return;
		const key = checkpointKey(latest);
		if (!key || key === applied) return;
		const current = generation;
		const allowed = () => !stopped && follow && current === generation && key === checkpointKey(latest) && checkpointView(latest).followAllowed;
		busy = true;
		try {
			if (await focus(latest.lastCheckpoint, allowed) !== false && allowed()) applied = key;
		} finally { busy = false; }
	}
	return {
		update(status) { latest = status; return apply(); },
		setEnabled(value) { follow = !!value; generation++; if (follow) applied = null; return apply(); },
		destroy() { stopped = true; generation++; },
	};
}

export function gameCheckpoint(host, { focus }) {
	let enabled = true;
	try { enabled = localStorage.getItem(FOLLOW_KEY) !== 'false'; } catch { /* private browsing */ }
	const make = (tag, text, cls) => { const el = document.createElement(tag); if (text) el.textContent = text; if (cls) el.className = cls; return el; };
	const title = make('strong', 'Game checkpoint');
	const summary = make('span', 'Waiting for /psrec on in game, then /reload.', 'checkpoint-summary');
	const saved = make('span', 'Saved, not live', 'checkpoint-saved');
	const detail = make('span', '', 'checkpoint-detail');
	const label = make('label', '', 'checkpoint-follow');
	const toggle = document.createElement('input');
	toggle.type = 'checkbox'; toggle.checked = enabled;
	label.append(toggle, 'Follow saved step');
	host.append(title, summary, saved, label, detail);
	host.setAttribute('aria-label', 'Game checkpoint');
	const follower = checkpointFollower({ focus, enabled });
	let status = null, timer = null, stopped = false;
	const render = () => {
		const view = checkpointView(status);
		summary.textContent = view.text;
		detail.textContent = ['waiting', 'error', 'stopped'].includes(view.state) && status ? view.detail : '';
		host.dataset.state = view.state;
		host.title = `${view.detail}\nSaved checkpoint only. The map character, XP and time remain a simulation.`;
	};
	toggle.addEventListener('change', () => {
		try { localStorage.setItem(FOLLOW_KEY, String(toggle.checked)); } catch { /* private browsing */ }
		follower.setEnabled(toggle.checked).catch(() => {});
	});
	async function poll() {
		try {
			const response = await fetch('/api/game-checkpoint', { cache: 'no-store', signal: AbortSignal.timeout(5000) });
			if (!response.ok) throw new Error(response.status === 404 ? 'Open the Planner with its project launcher to enable game checkpoints.' : 'Checkpoint helper is unavailable.');
			status = await response.json();
			if (stopped) return;
			render();
			await follower.update(status);
		} catch (error) {
			if (stopped) return;
			status = { ...status, state: 'error', followAllowed: false, message: error.message };
			render();
			await follower.update(status);
		} finally { if (!stopped) timer = setTimeout(poll, 2000); }
	}
	poll();
	return { destroy() { stopped = true; clearTimeout(timer); follower.destroy(); } };
}
