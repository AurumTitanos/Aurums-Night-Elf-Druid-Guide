#!/usr/bin/env node
'use strict';

// Import the actual OpenMap renderer, not a reimplementation of its artwork.
// The source checkout is data: this tool never loads or executes its Lua/Python.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const cp = require('node:child_process');

const ROOT = path.resolve(__dirname, '..');
const PIN = '849bac460b6ebcb110ef80fc27a6b08565069c74';
const URL = 'https://github.com/fitzforge/wowforever-openmap';
const OUT = path.join(ROOT, 'addon/Polestar/OpenMap');
const MEDIA = path.join(ROOT, 'addon/Polestar/Media/OpenMap/Textures');
const DATA = ['Reveal', 'Grade', 'Minimap', 'MinimapLOD', 'Caves', 'Gaps', 'Tones', 'ArtEdits', 'Labels', 'Banners', 'ZoneArt'];
const rel = p => path.relative(ROOT, p).split(path.sep).join('/');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const read = p => fs.readFileSync(p, 'utf8').replace(/\r\n/g, '\n');
const manifestPath = path.join(OUT, 'provenance.json');
const args = process.argv.slice(2);

// The native client's UiMapAssignment rectangles, on Azeroth (947). Pinned
// explicitly so rebuilding this mask never needs a remote DB2 service/cache.
// Source: build 1.60.1.70425 UiMapAssignment.csv SHA256 below; the independently
// generated tests/fixtures/openmap/native-maps.json verifies these rectangles.
const NATIVE_MASK = {
  build: '1.60.1.70425',
  assignmentSha256: '79267e8be8034e47daab14350411b3acc0b1f64e86efc9d821a217497254ca0a',
  continent: 1414, zone: 1438,
  continentRect: [-0.18589326491949285, 0.6340912982438116, 0.06767681692474252, 0.8877435933533173],
  zoneRect: [0.10939219123882231, 0.22284625178787312, 0.10005571560090802, 0.21349797345343963],
};

function tgaAlpha(bytes) {
  if (bytes[1] !== 0 || bytes[2] !== 2 || bytes[16] !== 32) throw new Error('Expected an uncompressed 32-bit source TGA mask');
  const width = bytes.readUInt16LE(12), height = bytes.readUInt16LE(14);
  const offset = 18 + bytes[0], top = (bytes[17] & 32) !== 0, right = (bytes[17] & 16) !== 0;
  if (bytes.length < offset + width * height * 4) throw new Error('Truncated TGA mask');
  const alpha = new Uint8Array(width * height);
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const sx = right ? width - 1 - x : x, sy = top ? y : height - 1 - y;
    alpha[y * width + x] = bytes[offset + (sy * width + sx) * 4 + 3];
  }
  return { width, height, alpha };
}

function nativeDetailMask(continent, island) {
  const c = NATIVE_MASK.continentRect, z = NATIVE_MASK.zoneRect;
  const bytes = Buffer.alloc(18 + continent.width * continent.height * 4);
  bytes[2] = 2; bytes.writeUInt16LE(continent.width, 12); bytes.writeUInt16LE(continent.height, 14);
  bytes[16] = 32; bytes[17] = 40; // top-left origin, eight alpha bits
  const sample = (u, v) => {
    if (u < 0 || u > 1 || v < 0 || v > 1) return 0;
    const fx = u * island.width - 0.5, fy = v * island.height - 0.5;
    const x = Math.floor(fx), y = Math.floor(fy), dx = fx - x, dy = fy - y;
    const at = (a, b) => island.alpha[Math.max(0, Math.min(island.height - 1, b)) * island.width + Math.max(0, Math.min(island.width - 1, a))];
    return Math.round((at(x, y) * (1 - dx) + at(x + 1, y) * dx) * (1 - dy) +
      (at(x, y + 1) * (1 - dx) + at(x + 1, y + 1) * dx) * dy);
  };
  for (let y = 0; y < continent.height; y++) for (let x = 0; x < continent.width; x++) {
    const u = c[0] + (x + 0.5) / continent.width * (c[1] - c[0]);
    const v = c[2] + (y + 0.5) / continent.height * (c[3] - c[2]);
    const a = Math.max(continent.alpha[y * continent.width + x], sample((u - z[0]) / (z[1] - z[0]), (v - z[2]) / (z[3] - z[2])));
    const p = 18 + (y * continent.width + x) * 4;
    bytes[p] = bytes[p + 1] = bytes[p + 2] = 255; bytes[p + 3] = a;
  }
  return bytes;
}

function check() {
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  if (manifest.commit !== PIN) throw new Error('OpenMap import has an unexpected upstream commit');
  if (manifest.generatorSha256 !== sha(fs.readFileSync(__filename))) throw new Error('OpenMap importer changed; regenerate the pinned import before using it');
  const bad = [];
  for (const f of manifest.files) {
    const p = path.join(ROOT, f.path);
    if (!fs.existsSync(p) || sha(fs.readFileSync(p)) !== f.sha256) bad.push(f.path);
  }
  if (bad.length) throw new Error(`OpenMap imported files missing or changed (${bad.length}):\n${bad.slice(0, 12).join('\n')}`);
  console.log(`OpenMap ${PIN.slice(0, 12)}: verified ${manifest.files.length} imported files (${manifest.mediaFiles} media assets).`);
}

function importSource(source) {
  source = path.resolve(source);
  const commit = cp.execFileSync('git', ['-C', source, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  if (commit !== PIN) throw new Error(`Expected OpenMap ${PIN}; source is ${commit}`);
  // Detect modified upstream files as well as the HEAD identity.
  const dirty = cp.execFileSync('git', ['-C', source, 'status', '--porcelain', '--untracked-files=no'], { encoding: 'utf8' }).trim();
  if (dirty) throw new Error('The pinned OpenMap checkout has tracked modifications');
  fs.mkdirSync(OUT, { recursive: true });
  fs.mkdirSync(MEDIA, { recursive: true });
  const files = [];
  let mediaFiles = 0;
  const put = (dest, bytes, origin) => {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, bytes);
    files.push({ path: rel(dest), source: origin, sha256: sha(Buffer.isBuffer(bytes) ? bytes : Buffer.from(bytes)) });
  };
  const preface = '-- OpenMap contributors, MIT; mechanically embedded for independent Polestar views.\n' +
    `-- Source: ${URL}, commit ${PIN}. See LICENSE.txt and NOTICE.md.\n`;
  for (const name of DATA) {
    const origin = `OpenMap/Data/${name}.lua`;
    const body = read(path.join(source, origin)).replace('local _, ns = ...',
      'local _, owner = ...\nowner.LiveOpenMap = owner.LiveOpenMap or {}\nowner.LiveOpenMap.Data = owner.LiveOpenMap.Data or {}\nlocal ns = owner.LiveOpenMap.Data');
    put(path.join(OUT, 'Data', `${name}.lua`), preface + body, origin);
  }
  for (const name of ['Stitch', 'Close']) {
    const origin = `OpenMap/Map/${name}.lua`;
    let body = read(path.join(source, origin)).replace('local _, ns = ...', 'local ns = context');
    if (name === 'Stitch') {
      // Both of these frames have no parent upstream. Suspend their bounded
      // loading/letter-halo jobs when the containing Polestar view is hidden.
      body += '\n-- Embedding lifecycle: hidden planner windows do no background frame work.\n' +
        'function S.SetPaused(paused)\n' +
        '\tif paused then\n\t\tloader:Hide()\n\t\tif names.watch then names.watch:Hide() end\n' +
        '\telse\n\t\tif loadAt <= #loadQueue or fadingN > 0 then loader:Show() end\n' +
        '\t\tif names.hushed and names.watch then names.watch:Show() end\n\tend\nend\n';
    }
    put(path.join(OUT, `${name}.lua`), preface +
      `local _, owner = ...\nowner.LiveOpenMap = owner.LiveOpenMap or {}\nowner.LiveOpenMap._${name.toLowerCase()} = function(context)\n` + body + '\nend\n', origin);
  }
  function copyTree(dir, dest) {
    for (const ent of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      // The planner has its own compact frame; OpenMap's decorative frame is unused.
      if (ent.isDirectory() && ent.name === 'MapBorder') continue;
      const p = path.join(dir, ent.name), out = path.join(dest, ent.name);
      if (ent.isDirectory()) copyTree(p, out);
      else { put(out, fs.readFileSync(p), path.relative(source, p).split(path.sep).join('/')); mediaFiles++; }
    }
  }
  copyTree(path.join(source, 'OpenMap/Media/Textures'), MEDIA);
  // OpenMap's continent art omits Teldrassil. Its native-detail LandMask
  // therefore erases that island's minimap, although its zone art includes it.
  // Repair only the native/LOD mask: preserve every original mainland alpha
  // sample and union the original zone coastline at its real map rectangle.
  put(path.join(MEDIA, 'NativeDetailLand/1414.tga'), nativeDetailMask(
    tgaAlpha(fs.readFileSync(path.join(MEDIA, 'MapLand/1414.tga'))),
    tgaAlpha(fs.readFileSync(path.join(MEDIA, 'MapZoneLand/1438.tga')))),
  'generated alpha union: OpenMap/Media/Textures/MapLand/1414.tga + MapZoneLand/1438.tga');
  mediaFiles++;
  put(path.join(OUT, 'LICENSE.txt'), read(path.join(source, 'LICENSE')), 'LICENSE');
  put(path.join(OUT, 'NOTICE.md'), '# Embedded OpenMap renderer\n\n' +
    `Imported from [fitzforge/wowforever-openmap](${URL}) at commit \`${PIN}\`. ` +
    'OpenMap is by jiforever and the OpenMap contributors; this repository is an unofficial mirror.\n\n' +
    'The Lua renderer and data retain the MIT license in LICENSE.txt. The mechanical wrappers give each ' +
    'Polestar map its own namespace and closures. The sole renderer addition pauses the two upstream ' +
    'background loading/lettering frames while a planner is hidden. Core.lua, WorldMap.lua, Init.lua and ' +
    'API.lua are not loaded; this embed does not activate the OpenMap addon or change the game world map.\n\n' +
    'The map uses the exact OpenMap stitched artwork with its Minimap detail option enabled. It does ' +
    'not generate place labels. Names remain those in the original map artwork.\n\n' +
    '**Native-detail island mask:** `NativeDetailLand/1414.tga` is generated by ' +
    '`tools/import-live-openmap.js`: the alpha MAX union of the unmodified OpenMap ' +
    '`MapLand/1414.tga` and its original `MapZoneLand/1438.tga`, bilinearly placed at ' +
    'Teldrassil\'s pinned native-client rectangle. RGB is white; only the alpha is used. ' +
    'This fixes the continent mask erasing detailed terrain on an island its own art omits. ' +
    'The painted map masks and artwork remain unmodified. This derived mask remains ' +
    'Blizzard Entertainment\'s game art, under the attribution below.\n\n' +
    'Generated media is intentionally excluded from Git. Rebuild with ' +
    '`node tools/import-live-openmap.js --source <pinned-checkout>`; verify with ' +
    '`node tools/import-live-openmap.js --check`. New client texture files require a full game restart.\n\n' +
    read(path.join(source, 'OpenMap/Media/Textures/NOTICE.md')), 'OpenMap/Media/Textures/NOTICE.md');
  const xml = ['<Ui xmlns="http://www.blizzard.com/wow/ui/">',
    ...DATA.map(n => `\t<Script file="Data/${n}.lua"/>`),
    '\t<Script file="Stitch.lua"/>', '\t<Script file="Close.lua"/>', '</Ui>', ''].join('\n');
  put(path.join(OUT, 'OpenMap.xml'), xml, 'generated load order');
  fs.writeFileSync(manifestPath, JSON.stringify({ repository: URL, commit: PIN, tool: 'tools/import-live-openmap.js',
    generatorSha256: sha(fs.readFileSync(__filename)),
    nativeDetailMask: NATIVE_MASK,
    renderer: 'OpenMap Stitch.lua + Close.lua, isolated namespaces', mediaFiles,
    mediaBytes: files.filter(f => f.path.includes('/Media/OpenMap/')).reduce((n, f) => n + fs.statSync(path.join(ROOT, f.path)).size, 0),
    files }, null, 2) + '\n');
  check();
}

module.exports = { nativeDetailMask, tgaAlpha, NATIVE_MASK };

if (require.main === module) try {
  if (args.includes('--check')) check();
  else {
    const i = args.indexOf('--source');
    importSource(i >= 0 && args[i + 1] ? args[i + 1] : path.resolve(ROOT, '../upstream-candidates/wowforever-openmap'));
  }
} catch (err) { console.error(err.message); process.exitCode = 1; }
