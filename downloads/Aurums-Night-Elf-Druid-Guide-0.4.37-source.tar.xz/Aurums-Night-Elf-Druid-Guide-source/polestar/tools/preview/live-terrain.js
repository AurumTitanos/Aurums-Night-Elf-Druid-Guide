'use strict';

// Local visual QA of the actual LiveDashboard/LiveMap Lua with the same
// terrain FileDataIDs as Planner. Character, quests and route are fixtures.
// Art is decoded only from the existing local cache: no downloads and no
// generated artwork is placed in the addon or a shareable guide package.
// Usage: node tools/preview/live-terrain.js <output directory>
const fs = require('node:fs');
const path = require('node:path');
const P = require('../commands/preview');
const { runAddon, ROOT } = require('../../tests/helpers/lua');
const { svg, compose, TextureCache } = require('./render');
const { readBlp, decodeMip } = require('../lib/planner/art/blp');
const { downsample2 } = require('../lib/planner/art/bc1');
const { newestCachedBuild } = require('../lib/planner/art/casc');

const FILES = ['Core/Core.xml', 'Theme/Theme.xml', 'Nav/Regions.lua', 'Maps/RouteStrokes.lua', 'UI/UI.xml'];
const MAP = 1438;
const GUIDE = 'forever/alliance/nightelf/01-teldrassil';

function lua(value) {
	if (Array.isArray(value)) return '{' + value.map(lua).join(',') + '}';
	if (value && typeof value === 'object') return '{' + Object.entries(value).map(([k, v]) => `[${/^\d+$/.test(k) ? k : JSON.stringify(k)}]=${lua(v)}`).join(',') + '}';
	return value == null ? 'nil' : JSON.stringify(value);
}

function fixture() {
 const customGuides = path.resolve(ROOT, '../druid-guide/dist/PolestarPack_AurumForeverDruid/Guides.lua');
 const customData = fs.existsSync(customGuides) ? `local captured
local savedRegister = Polestar.RegisterGuide
Polestar.RegisterGuide = function(guide) if guide.id == "aurum-druid/start-here" then captured = guide end end
assert(loadfile(${JSON.stringify(customGuides.replace(/\\/g, '/'))}))()
Polestar.RegisterGuide = savedRegister
assert(captured and captured.steps[14], "Missing compiled custom step 14")
for i, goal in ipairs(captured.steps[14].goals) do
  local dest = g.steps[3].goals[i]
  if dest then
    for _, k in ipairs({"map", "x", "y", "f", "spots", "spread", "item"}) do dest[k] = goal[k] end
  end
end
uistub.target = { map=1438, x=58.7, y=58.3, label="Collect Nightsaber Fang", stepIndex=3, goalIndex=1 }
local c,wx,wy = C.MapToWorld(1438,58.7,58.3)
S.geometry.legs[1].pts[#S.geometry.legs[1].pts] = {c,wx,wy}
` : '';
	const frames = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/forever/map-frames.json'), 'utf8')).forever;
	const bounds = Object.fromEntries([1438, 1414].map((id) => [id, frames[id]]));
	if (!bounds[MAP] || !bounds[1414]) throw new Error('Teldrassil/Kalimdor bounds are not cached.');
	return `
local bounds = ${lua(bounds)}
local S, C = livestub, Polestar.Compat
S.maps[1438] = { name = "Teldrassil", mapID = 1438, mapType = 3, parentMapID = 1414 }
S.maps[1414] = { name = "Kalimdor", mapID = 1414, mapType = 2, parentMapID = 947 }
S.player = { map = 1438, x = 58.2, y = 57.8, facing = 0 }
C.MapToWorld = function(map, x, y)
  local b = bounds[map]
  if not b or type(x) ~= "number" or type(y) ~= "number" then return end
  return b.c, b.top + (b.bottom - b.top) * y / 100, b.left + (b.right - b.left) * x / 100
end
C.WorldToMap = function(c, wx, wy, map)
  local b = bounds[map]
  if not b or c ~= b.c then return end
  return (wy - b.left) / (b.right - b.left) * 100, (wx - b.top) / (b.bottom - b.top) * 100
end
GetSubZoneText = function() return "Dolanaar" end
-- Example bends exercise the real route renderer; these are deliberately
-- sample coordinates, not a claim about the nav solver's preferred path.
local pts = {}
for _, p in ipairs({ {58.2,57.8}, {58.4,56.9}, {59.2,56.4}, {60.4,56.2} }) do
  local c, wx, wy = C.MapToWorld(1438, p[1], p[2])
  pts[#pts + 1] = { c, wx, wy }
end
S.geometry = { legs = { { kind = "walk", current = true, pts = pts } } }
uistub.target = { map = 1438, x = 60.4, y = 56.2 }
local g = uistub.guides[${JSON.stringify(GUIDE)}]
g.title = "01 - Teldrassil and Bear Form"
g.steps = {
  { title = "Dolanaar", goals = {
    { t = "turnin", verb = "Turn in", subject = "Dolanaar Delivery", subjectKind = "quest", quest = 2159, map = 1438, x = 55.6, y = 59.8, status = "done" },
    { t = "sethome", verb = "Set hearthstone to", subject = "Dolanaar", subjectKind = "place", map = 1438, x = 55.6, y = 59.8, status = "done" },
    { t = "train", verb = "Train", subject = "Druid spells", subjectKind = "text", status = "done" },
    { t = "accept", verb = "Accept", subject = "Crown of the Earth", subjectKind = "quest", quest = 929, status = "done" },
  } },
  { title = "Zenn Foulhoof", note = "Zenn sits by the road just east of Dolanaar, on the way to Starbreeze Village.", goals = {
    { t = "accept", verb = "Accept", subject = "Zenn's Bidding", subjectKind = "quest", quest = 488, npc = 2150, npcName = "Zenn Foulhoof", map = 1438, x = 60.4, y = 56.2, status = "done" },
  } },
  { title = "Zenn's Bidding and the moonwell", note = "Nightsabers, Strigid Owls and Webwood Lurkers live along the road east. The moonwell is at the west edge of Starbreeze Village.", goals = {
    { t = "collect", verb = "Collect", subject = "Nightsaber Fang", subjectKind = "item", quest = 488, item = 3409, progress = { cur = 1, max = 3 }, map = 1438, x = 60.4, y = 56.2, status = "active" },
    { t = "collect", verb = "Collect", subject = "Strigid Owl Feather", subjectKind = "item", quest = 488, item = 3411, progress = { cur = 0, max = 3 }, status = "active" },
    { t = "collect", verb = "Collect", subject = "Webwood Spider Silk", subjectKind = "item", quest = 488, item = 3412, progress = { cur = 2, max = 3 }, status = "active" },
    { t = "collect", verb = "Collect", subject = "Filled Jade Phial", subjectKind = "item", quest = 929, map = 1438, x = 63.4, y = 58.1, status = "pending" },
    { t = "turnin", verb = "Turn in", subject = "Zenn's Bidding", subjectKind = "quest", quest = 488, map = 1438, x = 60.35, y = 56.16, status = "pending" },
  } },
  { title = "Dolanaar quests", goals = {
    { t = "turnin", verb = "Turn in", subject = "Crown of the Earth", subjectKind = "quest", quest = 929, status = "pending" },
    { t = "accept", verb = "Accept", subject = "The Emerald Dreamcatcher", subjectKind = "quest", quest = 2438, status = "pending" },
    { t = "accept", verb = "Accept", subject = "Twisted Hatred", subjectKind = "quest", quest = 932, status = "pending" },
  } },
  { title = "East to Starbreeze Village", goals = {
    { t = "goto", verb = "Go to", subject = "Starbreeze Village", subjectKind = "place", map = 1438, x = 66.3, y = 58.5, status = "pending" },
    { t = "collect", verb = "Collect", subject = "Emerald Dreamcatcher", subjectKind = "item", quest = 2438, status = "pending" },
    { t = "collect", verb = "Collect", subject = "Fel Cone", subjectKind = "item", quest = 489, progress = { cur = 0, max = 3 }, status = "pending" },
  } },
  { title = "Denalan", goals = {
    { t = "accept", verb = "Accept", subject = "Timberling Seeds", subjectKind = "quest", quest = 918, status = "pending" },
    { t = "accept", verb = "Accept", subject = "Timberling Sprouts", subjectKind = "quest", quest = 919, status = "pending" },
    { t = "collect", verb = "Collect", subject = "Timberling Seed", subjectKind = "item", quest = 918, progress = { cur = 0, max = 8 }, status = "pending" },
  } },
}
${customData}
uistub.setGuide(${JSON.stringify(GUIDE)}, 3)
-- Sample live APIs exercise the real character panel too. These are QA
-- fixtures, never written into the addon or a user's saved character.
local quests = { { questID = 488, title = "Zenn's Bidding", isHeader = false }, { questID = 929, title = "Crown of the Earth", isHeader = false } }
C_QuestLog = C_QuestLog or {}
C_QuestLog.GetNumQuestLogEntries = function() return 2, 2 end
C_QuestLog.GetMaxNumQuestsCanAccept = function() return 20 end
C_QuestLog.GetInfo = function(i) return quests[i] end
C_QuestLog.ReadyForTurnIn = function() return false end
C_QuestLog.GetQuestObjectives = function(id)
  if id == 488 then return {
    { text = "Nightsaber Fang", numFulfilled = 1, numRequired = 3, finished = false },
    { text = "Strigid Owl Feather", numFulfilled = 0, numRequired = 3, finished = false },
    { text = "Webwood Spider Silk", numFulfilled = 2, numRequired = 3, finished = false },
  } end
  return { { text = "Filled Jade Phial", numFulfilled = 0, numRequired = 1, finished = false } }
end
Polestar.QoL.GetHearth = function() return { have = true, ready = true, remaining = 0, bind = "Dolanaar" } end
UnitOnTaxi = function() return false end; IsFlying = UnitOnTaxi; IsMounted = UnitOnTaxi; IsSwimming = UnitOnTaxi
C_Container = {
  GetContainerNumSlots = function(bag) return bag == 0 and 2 or 0 end,
  GetContainerItemInfo = function(_, slot) return { itemID = slot == 1 and 3409 or 3412, stackCount = slot } end,
}
C_Item = C_Item or {}
C_Item.GetItemInfoInstant = function(id) return id, "Quest", "Quest", "", 1, 12 end
C_Item.GetItemNameByID = function(id) return id == 3409 and "Nightsaber Fang" or "Webwood Spider Silk" end
-- Questie registry-shaped QA fixtures. These sample spawn coordinates are
-- for visual coverage, not observed player data or a replacement database.
QuestieLoader = { _modules = { QuestieMap = { questIdFrames = { [488] = {} } } } }
Questie = { db = { profile = { alwaysGlowMinimap = true, alwaysGlowMap = false, questMinimapObjectiveColors = false } },
  icons = { glow = "Interface/AddOns/Questie/Icons/glow.blp" } }
local objectiveColors = { {1,.7,.1}, {.2,1,.4}, {.8,.4,1} }
for i, mob in ipairs({ {"Nightsaber", "Nightsaber Fang",58.7,58.3}, {"Strigid Owl","Strigid Owl Feather",58.86,60.29}, {"Webwood Lurker","Webwood Spider Silk",59.55,59.7} }) do
  for j=1,5 do
    local name="QuestiePreview"..i.."_"..j
    local pin=CreateFrame("Frame",name,UIParent)
    pin.UiMapID,pin.x,pin.y=1438,mob[3]+(j-3)*.9,mob[4]+(j%3-1)*1.2
    pin.data={Id=488,Type="item",Name=mob[1],ObjectiveIndex=i,QuestData={name="Zenn's Bidding"},ObjectiveData={Description=mob[2],Collected=0,Needed=3,Color=objectiveColors[i]}}
    pin.texture=pin:CreateTexture(); pin.texture:SetTexture("Interface/AddOns/Questie/Icons/loot.blp")
    pin.texture:SetVertexColor(1,1,1,1)
    pin:Hide()
    QuestieLoader._modules.QuestieMap.questIdFrames[488][name]=name
  end
end
stub.fire("QUEST_LOG_UPDATE"); stub.fire("BAG_UPDATE_DELAYED")
`;
}

function dump(width, height, extra = '', compact = false) {
	const fonts = P.loadFonts();
	const before = `${P.metricsLua(fonts)}\ndofile(${JSON.stringify(path.join(ROOT, 'tools/preview/stub.lua'))})`;
	const out = runAddon({
		stubs: ['stub_ui.lua', 'live-dashboard.lua'], before,
		addons: [{ name: 'Polestar', files: FILES }],
		script: `local nativeTerrain = Polestar.LiveTerrain
uistub.install(); livestub.install(); Polestar.LiveTerrain = nativeTerrain; stub.login()
${fixture()}
Polestar.Set("${compact ? 'liveMiniMap' : 'liveDashboard'}.width", ${width}); Polestar.Set("${compact ? 'liveMiniMap' : 'liveDashboard'}.height", ${height})
local D = Polestar.${compact ? 'LiveMiniMap' : 'LiveDashboard'}
D.Show()
local F = D.GetFrame()
-- Explicit sizes supply the generic test client's missing anchor solver;
-- the SVG renderer solves the actual anchors when painting the dump.
${compact ? '' : 'F.List:SetHeight(F:GetHeight() - 138)'}
F.Map.Viewport:SetSize(F.Map:GetWidth(), F.Map:GetHeight() - ${compact ? 0 : 103})
F.Map.View = false
F.Map:ApplyViewState({ mapID = 1438, zoom = 4, follow = true })
${extra}
D.Refresh(true)
local terrainIDs = {}
for _, t in ipairs(F.Map.Tiles) do
  if t:IsShown() then terrainIDs[#terrainIDs + 1] = t.terrainFile end
end
preview.emit({ terrainIDs = terrainIDs, view = F.Map:GetViewState(), tileCount = F.Map.tileCount,
  sampleData = true, art = "Native client minimap textures (same source as Planner)" })`,
	}).emitted;
	return { scene: out[out.length - 1], fonts };
}

function tga(width, height, rgba) {
	const out = Buffer.alloc(18 + width * height * 4);
	out[2] = 2;
	out.writeUInt16LE(width, 12); out.writeUInt16LE(height, 14);
	out[16] = 32; out[17] = 0x28; // top-left, eight alpha bits
	for (let i = 0; i < width * height; i++) {
		const from = i * 4, to = 18 + from;
		out[to] = rgba[from + 2]; out[to + 1] = rgba[from + 1]; out[to + 2] = rgba[from]; out[to + 3] = rgba[from + 3];
	}
	return out;
}

function resolveArt(scene, directory) {
	const productDir = path.join(ROOT, 'data/sources/casc/wow_classic_beta');
	const build = newestCachedBuild(productDir);
	if (!build) throw new Error('No local Forever client artwork cache. This QA tool does not download assets.');
	fs.mkdirSync(directory, { recursive: true });
	const required = new Set(Object.values(scene.extra.terrainIDs));
	if (!required.size) throw new Error('The actual terrain renderer produced no visible tiles; refusing a blank or synthetic preview.');
	const ids = new Set(scene.objects.filter((o) => typeof o.texture === 'number').map((o) => o.texture));
	const resolution = new Map();
	for (const o of scene.objects) {
		if (typeof o.texture !== 'number') continue;
		const uv = o.texCoord;
		const span = uv && uv.length === 4 ? Math.max(0.001, uv[1] - uv[0]) : 1;
		resolution.set(o.texture, Math.max(resolution.get(o.texture) || 0, (o.w || 512) / span * 2));
	}
	const converted = [], unavailableIcons = [];
	for (const id of ids) {
		const source = path.join(productDir, build, `${id}.blp`);
		if (!fs.existsSync(source)) {
			if (required.has(id)) throw new Error(`Visible terrain texture ${id} is absent from the offline cache.`);
			unavailableIcons.push(id);
			continue;
		}
		const dest = path.join(directory, `${id}.tga`);
		const blp = readBlp(fs.readFileSync(source));
		// Use the client's own mip chain for zoomed-out QA. The displayed
		// content is unchanged, while a continent SVG stays reasonably small.
		let level = 0;
		while (level + 1 < blp.mips.length && blp.mips[level + 1].width >= resolution.get(id)) level++;
		const mip = blp.mips[level];
		let w = mip.width, h = mip.height, pixels = decodeMip(blp, level);
		// Native minimap BLPs may contain only level zero. Make local preview
		// mips as the Planner does, so a continent does not embed 943 full-size
		// PNGs in its SVG. This changes QA resolution, never addon assets.
		while (w / 2 >= Math.max(16, resolution.get(id) || 16) && h > 1) {
			pixels = downsample2(pixels, w, h); w = Math.max(1, w / 2); h = Math.max(1, h / 2);
		}
		const existing = fs.existsSync(dest) && fs.readFileSync(dest);
		if (!existing || existing.readUInt16LE(12) !== w || existing.readUInt16LE(14) !== h) {
			fs.writeFileSync(dest, tga(w, h, pixels));
		}
		converted.push(id);
	}
	return { build, terrainTiles: required.size, converted, unavailableIcons };
}

function render(outDir, compactOnly = false) {
	fs.mkdirSync(outDir, { recursive: true });
	const results = [];
	for (const [name, w, h, extra] of [
		['dolanaar', 1400, 850, ''],
		['minimum', 1080, 650, ''],
        ['objectives-off', 1400, 850, 'F.Map:SetObjectives(false); F.Map:SetAreaStyle("off"); F.Map:SetQuestie(false)'],
        ['circles', 1400, 850, 'F.Map:SetAreaStyle("circles")'],
        ['layers', 1400, 850, 'F.Map:ShowLayers(); stub.advance(0.3)'],
		['zone', 1400, 850, 'F.Map:ApplyViewState({ mapID = 1438, zoom = 1, follow = false, focusX = 50, focusY = 50 })'],
		['continent', 1400, 850, 'F.Map:SetMapID(1414)'],
		['compact', 420, 380, 'F.Map:ApplyViewState({mapID=1438,zoom=8,follow=true})'],
		['compact-minimum', 320, 180, 'F.Map:ApplyViewState({mapID=1438,zoom=8,follow=true})'],
		['compact-options', 420, 380, 'Polestar.LiveMiniMap.ShowOptions(); stub.advance(0.3)'],
		['compact-locked', 420, 380, 'Polestar.LiveMiniMap.SetLocked(true); Polestar.LiveMiniMap.SetOpacity(0.5)'],
		['compact-continent', 420, 380, 'F.Map:SetMapID(1414)'],
	]) {
		const compact = name.startsWith('compact');
		if (compactOnly && !compact) continue;
		const { scene, fonts } = dump(w, h, extra, compact);
		const clientArtDir = path.join(outDir, 'client-art-local-only', name);
		const textures = new TextureCache(path.join(ROOT, 'addon/Polestar/Media/UI'), clientArtDir);
		const art = resolveArt(scene, clientArtDir);
        // Preview-only resolution of installed Questie artwork. No external
        // addon assets are copied into the shipped Polestar bundle.
        const questieDir = process.env.POLESTAR_QUESTIE_DIR || 'C:/Program Files (x86)/World of Warcraft/_classic_beta_/Interface/AddOns/Questie';
        const qaIcons = new Map();
        for (const o of scene.objects) {
            const match = typeof o.texture === 'string' && /Questie[\\/]Icons[\\/]([a-z]+)\.blp$/i.exec(o.texture);
            if (!match) continue;
            let id = qaIcons.get(match[1]);
            if (!id) {
                const file = path.join(questieDir, 'Icons', match[1]+'.blp');
                if (!fs.existsSync(file)) continue;
                const blp = readBlp(fs.readFileSync(file)); const mip=blp.mips[0];
                id=900000000+qaIcons.size;qaIcons.set(match[1],id);
                fs.writeFileSync(path.join(clientArtDir,id+'.tga'),tga(mip.width,mip.height,decodeMip(blp,0)));
            }
            o.texture=id;
        }
		const shared = { glyphs: new Set(), defs: [] };
		const roots = [compact ? 'PolestarLiveMiniMap' : 'PolestarLiveDashboard'];
		if (name === 'layers' || name === 'compact-options') roots.push('PolestarMenu');
		const panel = svg(scene, { fonts, textures, roots, prefix: name, shared });
		const file = path.join(outDir, `live-terrain-${name}.svg`);
		fs.writeFileSync(file, compose([panel], { title: 'Actual addon Lua and real cached terrain artwork; sample character, quests and route — local visual QA', shared }));
		fs.writeFileSync(path.join(outDir, `live-terrain-${name}.json`), JSON.stringify(scene));
		results.push({ name, file, ...art, view: scene.extra.view });
	}
	fs.writeFileSync(path.join(outDir, 'terrain-preview-report.json'), JSON.stringify({ localOnly: true, downloads: 0, syntheticCharacterAndRoute: true, results }, null, 2));
	return results;
}

if (require.main === module) {
	if (!process.argv[2]) throw new Error('Pass a local QA output directory; cached game artwork must not be committed or bundled.');
	for (const result of render(path.resolve(process.argv[2]), process.argv.includes('--compact'))) console.log(JSON.stringify(result));
}

module.exports = { dump, render, tga };
