'use strict';

// Render the actual dashboard Lua with sample character/quest data. This is
// layout evidence, not a screenshot or a claim that the client was tested.
// Usage: node tools/preview/live-dashboard.js <output directory>
const fs = require('node:fs');
const path = require('node:path');
const P = require('../commands/preview');
const { runAddon, ROOT } = require('../../tests/helpers/lua');
const { svg, compose, TextureCache } = require('./render');

const FILES = ['Core/Core.xml', 'Theme/Theme.xml', 'Maps/RouteStrokes.lua', 'UI/UI.xml'];
function dump(width, height, extra = '') {
	const fonts = P.loadFonts();
	const prelude = P.metricsLua(fonts);
	const before = `${prelude}\ndofile(${JSON.stringify(path.join(ROOT, 'tools', 'preview', 'stub.lua'))})`;
	const out = runAddon({
		stubs: ['stub_ui.lua', 'live-dashboard.lua'], before,
		addons: [{ name: 'Polestar', files: FILES }],
		script: `uistub.install(); livestub.install(); stub.login()
uistub.setGuide(uistub.elwynn, 3)
Polestar.Set("liveDashboard.width", ${width}); Polestar.Set("liveDashboard.height", ${height})
local D = Polestar.LiveDashboard
D.Show()
local F = D.GetFrame()
-- These dimensions are inferred automatically by the real client. The
-- generic Lua stub only stores anchor constraints, so make them explicit
-- for runtime polling; the SVG renderer still solves the actual anchors.
F.List:SetHeight(F:GetHeight() - 188)
F.Map.Viewport:SetSize(F.Map:GetWidth(), F.Map:GetHeight() - 103)
F.Map.View = false
F.Map:Refresh(true)
${extra}
D.Refresh(true)
-- Synthetic flat map tiles make the art footprint legible without bundling
-- Blizzard artwork. Geometry, anchors, text, markers and route are real Lua.
for i, tile in ipairs(F.Map.Tiles) do
  if tile:IsShown() then tile:SetColorTexture(0.10 + (i % 2) * 0.02, 0.19 + (i % 2) * 0.02, 0.16, 1) end
end
preview.emit()` }).emitted;
	return { dump: out[out.length - 1], fonts };
}

function render(outDir) {
	fs.mkdirSync(outDir, { recursive: true });
	const textures = new TextureCache(path.join(ROOT, 'addon', 'Polestar', 'Media', 'UI'));
	const written = [];
	for (const [name, w, h, extra] of [
		['default', 1080, 760, ''],
		['minimum', 850, 600, ''],
		['browsing', 1080, 760, 'D.SelectStep(7)'],
	]) {
		const { dump: scene, fonts } = dump(w, h, extra);
		const shared = { glyphs: new Set(), defs: [] };
		const panel = svg(scene, { fonts, textures, roots: ['PolestarLiveDashboard'], prefix: name, shared });
		const file = path.join(outDir, `live-dashboard-${name}.svg`);
		fs.writeFileSync(file, compose([panel], { title: 'Actual addon Lua with synthetic character, quest and map data — layout QA', shared }));
		fs.writeFileSync(path.join(outDir, `live-dashboard-${name}.json`), JSON.stringify(scene));
		written.push(file);
	}
	return written;
}

if (require.main === module) {
	const out = process.argv[2];
	if (!out) throw new Error('Pass an output directory; previews are local QA artifacts.');
	for (const file of render(path.resolve(out))) console.log(file);
}

module.exports = { dump, render };
